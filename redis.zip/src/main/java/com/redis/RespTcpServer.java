package com.redis;


import org.springframework.stereotype.Component;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.*;

@Component
public class RespTcpServer {

    private final Store store = new Store();
    private final ExecutorService clientPool = Executors.newCachedThreadPool();
    private volatile ServerSocket serverSocket;
    private final ScheduledExecutorService cleaner = Executors.newSingleThreadScheduledExecutor();

    public RespTcpServer() {
        // background cleaner to remove expired keys periodically (optional)
        cleaner.scheduleAtFixedRate(store::purgeExpired, 1, 1, TimeUnit.SECONDS);
    }

    public void start(int port) {
        clientPool.submit(() -> {
            try (ServerSocket ss = new ServerSocket(port)) {
                this.serverSocket = ss;
                System.out.println("mini-redis listening on 0.0.0.0:" + port);
                while (!ss.isClosed()) {
                    Socket client = ss.accept();
                    clientPool.submit(() -> handleClient(client));
                }
            } catch (IOException e) {
                System.err.println("Server socket closed or failed: " + e.getMessage());
            }
        });
    }

    private void handleClient(Socket socket) {
        String peer = socket.getRemoteSocketAddress().toString();
        try (Socket s = socket;
             InputStream in = s.getInputStream();
             OutputStream out = s.getOutputStream()) {

            BufferedInputStream bin = new BufferedInputStream(in);
            while (!s.isClosed()) {
                // parse an array request (redis-cli sends arrays)
                List<Object> cmd;
                try {
                    cmd = RespParser.parseArray(bin);
                } catch (RespParser.ProtocolException pe) {
                    out.write(respError("Protocol error: " + pe.getMessage()));
                    out.flush();
                    break;
                } catch (EOFException eof) {
                    break;
                }

                if (cmd == null || cmd.isEmpty()) {
                    out.write(respError("empty command"));
                    out.flush();
                    continue;
                }

                byte[] first = toBytes(cmd.get(0));
                String command = new String(first, StandardCharsets.UTF_8).toUpperCase();

                byte[] response;
                switch (command) {
                    case "PING":
                        response = handlePing(cmd);
                        break;
                    case "ECHO":
                        response = handleEcho(cmd);
                        break;
                    case "SET":
                        response = handleSet(cmd);
                        break;
                    case "GET":
                        response = handleGet(cmd);
                        break;
                    default:
                        response = respError("unknown command '" + command.toLowerCase() + "'");
                }

                out.write(response);
                out.flush();
            }
        } catch (IOException e) {
            // client disconnected or IO error
        } finally {
            // cleanup if needed
        }
    }

    private byte[] handlePing(List<Object> cmd) {
        if (cmd.size() == 1) return respSimpleString("PONG");
        if (cmd.size() == 2) {
            byte[] arg = toBytes(cmd.get(1));
            return respBulkString(arg);
        }
        return respError("wrong number of arguments for 'PING' command");
    }

    private byte[] handleEcho(List<Object> cmd) {
        if (cmd.size() != 2) return respError("wrong number of arguments for 'ECHO' command");
        byte[] arg = toBytes(cmd.get(1));
        return respBulkString(arg);
    }

    private byte[] handleSet(List<Object> cmd) {
        if (cmd.size() < 3) return respError("wrong number of arguments for 'SET' command");
        byte[] key = toBytes(cmd.get(1));
        byte[] val = toBytes(cmd.get(2));
        Long exSeconds = null;
        Long pxMillis = null;
        int i = 3;
        while (i < cmd.size()) {
            Object o = cmd.get(i++);
            String token = new String(toBytes(o), StandardCharsets.UTF_8).toUpperCase();
            if ("EX".equals(token)) {
                if (i >= cmd.size()) return respError("syntax error");
                try {
                    exSeconds = Long.parseLong(new String(toBytes(cmd.get(i++)), StandardCharsets.UTF_8));
                } catch (Exception e) {
                    return respError("value is not an integer or out of range");
                }
            } else if ("PX".equals(token)) {
                if (i >= cmd.size()) return respError("syntax error");
                try {
                    pxMillis = Long.parseLong(new String(toBytes(cmd.get(i++)), StandardCharsets.UTF_8));
                } catch (Exception e) {
                    return respError("value is not an integer or out of range");
                }
            } else {
                return respError("syntax error");
            }
        }
        store.set(key, val, exSeconds, pxMillis);
        return respSimpleString("OK");
    }

    private byte[] handleGet(List<Object> cmd) {
        if (cmd.size() != 2) return respError("wrong number of arguments for 'GET' command");
        byte[] key = toBytes(cmd.get(1));
        byte[] val = store.get(key);
        return respBulkString(val);
    }

    // RESP helpers
    private static byte[] respSimpleString(String s) {
        return ( "+" + s + "\r\n" ).getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] respError(String s) {
        return ( "-" + "ERR " + s + "\r\n" ).getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] respBulkString(byte[] b) {
        if (b == null) return "$-1\r\n".getBytes(StandardCharsets.UTF_8);
        return ("$" + b.length + "\r\n").getBytes(StandardCharsets.UTF_8)
                .length == 0 ? new byte[0] : concat( ("$" + b.length + "\r\n").getBytes(StandardCharsets.UTF_8), b, "\r\n".getBytes(StandardCharsets.UTF_8) );
    }

    private static byte[] concat(byte[] a, byte[] b, byte[] c) {
        byte[] out = new byte[a.length + b.length + c.length];
        System.arraycopy(a,0,out,0,a.length);
        System.arraycopy(b,0,out,a.length,b.length);
        System.arraycopy(c,0,out,a.length+b.length,c.length);
        return out;
    }

    private static byte[] toBytes(Object o) {
        if (o == null) return null;
        if (o instanceof byte[]) return (byte[]) o;
        return o.toString().getBytes(StandardCharsets.UTF_8);
    }
}
