package com.redis;


import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Store {

    private final Map<String, ValueEntry> map = new ConcurrentHashMap<>();

    public void set(byte[] keyBytes, byte[] valueBytes, Long exSeconds, Long pxMillis) {
        String key = new String(keyBytes);
        long expireAt = -1;
        if (pxMillis != null) {
            expireAt = System.currentTimeMillis() + pxMillis;
        } else if (exSeconds != null) {
            expireAt = System.currentTimeMillis() + exSeconds * 1000;
        }
        ValueEntry entry = new ValueEntry(valueBytes, expireAt);
        map.put(key, entry);
    }

    public byte[] get(byte[] keyBytes) {
        String key = new String(keyBytes);
        ValueEntry e = map.get(key);
        if (e == null) return null;
        if (e.isExpired()) {
            map.remove(key);
            return null;
        }
        return e.getValue();
    }

    public void purgeExpired() {
        long now = System.currentTimeMillis();
        for (Map.Entry<String, ValueEntry> en : map.entrySet()) {
            ValueEntry v = en.getValue();
            if (v.getExpireAt() > 0 && v.getExpireAt() <= now) {
                map.remove(en.getKey(), v);
            }
        }
    }
}

