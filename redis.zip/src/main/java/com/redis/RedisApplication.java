package com.redis;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedisApplication.class, args);
		System.out.println("Redis App Started");
	}

	@Bean
	CommandLineRunner startServer(RespTcpServer server) {
		return args -> {
			int port = 6379;
			if (args.length > 0) {
				try {
					port = Integer.parseInt(args[0]);
				} catch (Exception ignored) {
				}
			}
			server.start(port);
		};
	}

}
