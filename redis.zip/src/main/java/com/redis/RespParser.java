package com.redis;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal RESP2 parser for arrays and bulk strings.
 * Only supports the subset needed for redis-cli (arrays of bulk strings).
 */
public class RespParser {

    public static class ProtocolException extends Exception {
        public ProtocolException(String msg) { super(msg); }
    }

    // Parse an array from the stream. Returns null for *-1, throws EOFException on stream end.
    public static List<Object> parseArray(BufferedInputStream in) throws IOException, ProtocolException {
        int first = in.read();
        if (first == -1) throw new EOFException();
        if (first != '*') throw new ProtocolException("expected array");
        String line = readLine(in);
        int count;
        try { count = Integer.parseInt(line); } catch (NumberFormatException e) { throw new ProtocolException("invalid array length"); }
        if (count == -1) return null;
        List<Object> items = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            int prefix = in.read();
            if (prefix == -1) throw new EOFException();
            if (prefix == '$') {
                String lenLine = readLine(in);
                int len;
                try { len = Integer.parseInt(lenLine); } catch (NumberFormatException e) { throw new ProtocolException("invalid bulk length"); }
                if (len == -1) {
                    items.add(null);
                } else {
                    byte[] buf = new byte[len];
                    int read = 0;
                    while (read < len) {
                        int r = in.read(buf, read, len - read);
                        if (r == -1) throw new EOFException();
                        read += r;
                    }
                    // consume CRLF
                    int c1 = in.read();
                    int c2 = in.read();
                    if (c1 != '\r' || c2 != '\n') throw new ProtocolException("bulk string missing CRLF");
                    items.add(buf);
                }
            } else if (prefix == '+') {
                String s = readLine(in);
                items.add(s);
            } else if (prefix == ':') {
                String s = readLine(in);
                try { items.add(Long.parseLong(s)); } catch (NumberFormatException e) { throw new ProtocolException("invalid integer"); }
            } else if (prefix == '-') {
                String s = readLine(in);
                items.add(new ProtocolException(s));
            } else {
                throw new ProtocolException("unknown prefix: " + (char)prefix);
            }
        }
        return items;
    }

    private static String readLine(BufferedInputStream in) throws IOException, ProtocolException {
        StringBuilder sb = new StringBuilder();
        int prev = -1;
        while (true) {
            int c = in.read();
            if (c == -1) throw new EOFException();
            if (prev == '\r' && c == '\n') {
                sb.setLength(sb.length() - 1); // remove CR
                return sb.toString();
            }
            sb.append((char)c);
            prev = c;
            // guard: if line grows too big, still allow but could be limited
        }
    }
}
