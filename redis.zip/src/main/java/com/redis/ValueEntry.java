package com.redis;



public class ValueEntry {
    private final byte[] value;
    private final long expireAt; // -1 for no expiry, epoch millis

    public ValueEntry(byte[] value, long expireAt) {
        this.value = value;
        this.expireAt = expireAt;
    }

    public byte[] getValue() { return value; }
    public long getExpireAt() { return expireAt; }
    public boolean isExpired() {
        return expireAt > 0 && System.currentTimeMillis() >= expireAt;
    }
}
